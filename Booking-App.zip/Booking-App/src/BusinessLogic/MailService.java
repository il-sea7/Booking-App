package BusinessLogic;

public class MailService {

}

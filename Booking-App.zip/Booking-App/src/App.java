import Presentation.*;

public class App {
    public static void main(String[] args) throws Exception {

        MainMenu mm = new MainMenu();
        mm.Display(true);
    }
}

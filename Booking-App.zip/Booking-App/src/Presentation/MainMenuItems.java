package Presentation;

public enum MainMenuItems {
    Register, 
    Login,
    Exit
}

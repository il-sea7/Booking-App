package Presentation;

public enum EmployeeMenuItems {
    ViewBookings,
    Exit
}
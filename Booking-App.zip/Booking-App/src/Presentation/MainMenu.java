package Presentation;

import java.util.*;
import DataAccess.*;

public class MainMenu {

    Customer cust = new Customer();
    public List<Customer> customerList = new ArrayList<Customer>();

    public void Display(Boolean loggedIn) {

        Scanner sc = new Scanner(System.in);

        String option;

        while (loggedIn) {
            for (int i = 0; i < MainMenuItems.values().length; i++) {
                System.out.printf("\n %d %s", i + 1, MainMenuItems.values()[i]);
            }

            option = sc.nextLine();
            System.out.print(option);

            switch (Integer.parseInt(option)) {
            case 1:

                Customer.Register(cust, customerList);
                break;

            case 2:
                Person.login();
                break;
            case 3:
                loggedIn = false;
                break;
            }
        }
        sc.close();
    }
}

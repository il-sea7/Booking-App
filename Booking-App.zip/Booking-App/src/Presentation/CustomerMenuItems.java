package Presentation;

public enum CustomerMenuItems{
    Book,
    Update,
    Confirm,
    CheckStatus,
    Exit
}

package DataAccess;

import java.util.*;

public class Customer extends Person {

    public Customer() {

    }

    Customer(String id, String name, String surname, String phone) {
        super(id, name, surname, phone);
        // TODO Auto-generated constructor stub
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getPhone() {
        return phone;
    }

    public static void Register(Customer cust, List<Customer> lst) {

        Scanner input = new Scanner(System.in);
        System.out.println("Enter name");
        cust.name = input.nextLine();

        System.out.println("Enter surname");
        cust.surname = input.nextLine();

        System.out.println("Enter phone number");
        cust.phone = input.nextLine();

        cust.id = cust.name.substring(0, 4) + cust.phone.substring(8, 10);

        System.out.println("Your login username is: " + cust.id);

        lst.add(cust);

    }

}


package DataAccess;
import java.io.*;
import java.util.*;

import BusinessLogic.*;
public class DataHandler{
    //Added DataHandler class
    //Make changes
    public void writePerson(List<Person> lst, String filename)
    {
        try 
        {

            FileOutputStream fs=new FileOutputStream(filename);
            ObjectOutputStream out=new ObjectOutputStream(fs);

            for (Person p : lst){
                out.writeObject(p.name+";"+p.surname+";"+p.phone);
            }
            
            out.close();
            fs.close();

        } catch (Exception ex) 
        {
            System.out.print(ex.toString());
        }
    }
    public void writeBooking(List<Booking> lst, String filename)
    {
        try 
        {

            FileOutputStream fs=new FileOutputStream(filename);
            ObjectOutputStream out=new ObjectOutputStream(fs);
            for (Booking p : lst)
            {
                out.writeObject((p.getBookID()+";"+p.Cusname()+";"+p.getType()+";"+p.getVenue()+";"+p.getConfirm()).toString());
            }
            
            out.close();
            fs.close();

        } catch (Exception ex) 
        {
            System.out.print(ex.toString());
        }
    }
    
    public void ReadBooking(String filename)
    {
        try 
        {
            FileInputStream fs=new FileInputStream(filename);
            ObjectInputStream out=new ObjectInputStream(fs);
            String read= out.readUTF();
            String[] data=read.split(";");
            System.out.println("BookingID : "+data[0]+" Customer Name : "+data[1]+" Event Type : "+data[2]+" Venue : "+data[3]+" Confirmed : "+data[4]);
            out.close();
            fs.close();

        } catch (Exception ex) 
        {
            System.out.print(ex.toString());
        }
    }
}
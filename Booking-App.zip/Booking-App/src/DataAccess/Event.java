package DataAccess;

public class Event {

}
